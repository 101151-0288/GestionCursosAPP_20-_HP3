use GestionCursos

create table Estudiantes(
id_estudiante int primary key identity (1,1),
nombre varchar(100),
correo_electronico varchar(100)
);

create table Cursos(
id_curso int primary key identity (1,1),
nombre_curso varchar (100),
descripcion varchar (100)
);

create table Inscripcion(
id_inscripci�n int primary key identity (1,1),
id_estudiante int not null,
id_curso int not null,
foreign key (id_estudiante) references Estudiantes(id_estudiante),
foreign key (id_curso) references Cursos(id_curso)
);


INSERT INTO Estudiantes(nombre, correo_electronico) VALUES ('Juan Perez', 'juan@example.com');
INSERT INTO Estudiantes(nombre, correo_electronico) VALUES ('Maria Lopez', 'maria@example.com');

INSERT INTO Cursos (nombre_curso, descripcion) VALUES ('Matem�ticas', 'Curso introductorio de matem�ticas');
INSERT INTO Cursos (nombre_curso, descripcion) VALUES ('Programaci�n', 'Curso b�sico de programaci�n en Python');

INSERT INTO Inscripcion (id_estudiante, id_curso) VALUES (1, 1);
INSERT INTO Inscripcion (id_estudiante, id_curso) VALUES (2, 2);

