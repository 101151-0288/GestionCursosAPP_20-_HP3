import pyodbc
from prettytable import PrettyTable


connection_string = (
    "DRIVER={SQL Server};"
    ""  +
    "DATABASE=GestionCursos;"
    "Trusted_Connection=yes;"  
)


def ejecutar_consulta(query, params=None):
    try:
        with pyodbc.connect(connection_string) as conn:
            cursor = conn.cursor()
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            if query.strip().upper().startswith("SELECT"):
                return cursor.fetchall()
            conn.commit()
    except Exception as e:
        print(f"Error: {e}")

# Men� principal
def mostrar_menu():
    print("\n--- Gesti�n de Cursos y Estudiantes ---")
    print("1. Listar inscripciones")
    print("2. Agregar inscripci�n")
    print("3. Salir")

# Listar inscripciones
def listar_inscripciones():
    query = """
    SELECT i.id_inscripcion, e.nombre AS estudiante, c.nombre_curso AS curso
    FROM Inscripcion i
    INNER JOIN Estudiante e ON i.id_estudiante = e.id_estudiante
    INNER JOIN Curso c ON i.id_curso = c.id_curso
    """
    inscripciones = ejecutar_consulta(query)

    if inscripciones:
        tabla = PrettyTable()
        tabla.field_names = ["ID Inscripci�n", "Estudiante", "Curso"]
        for inscripcion in inscripciones:
            tabla.add_row([inscripcion.id_inscripcion, inscripcion.estudiante, inscripcion.curso])
        print(tabla)
    else:
        print("No hay inscripciones registradas.")

# Agregar inscripci�n
def agregar_inscripcion():
    id_estudiante = input("ID del estudiante: ")
    id_curso = input("ID del curso: ")
    query = "INSERT INTO Inscripcion (id_estudiante, id_curso) VALUES (?, ?)"
    ejecutar_consulta(query, (id_estudiante, id_curso))
    print("Inscripci�n agregada correctamente.")

# Funci�n principal
def main():
    while True:
        mostrar_menu()
        opcion = input("Seleccione una opci�n: ")

        if opcion == "1":
            listar_inscripciones()
        elif opcion == "2":
            agregar_inscripcion()
        elif opcion == "3":
            print("Saliendo del programa...")
            break
        else:
            print("Opci�n no v�lida. Intente de nuevo.")

if __name__ == "__main__":
    main()